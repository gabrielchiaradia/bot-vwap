import numpy as np
import pandas as pd

def calculate_vwap_bands(df, mult=2.5):
    df = df.copy()
    # Precio Típico
    df['typ'] = (df['high'] + df['low'] + df['close']) / 3
    df['typ_vol'] = df['typ'] * df['volume']
    
    # VWAP Acumulado (Para consistencia con el Backtest Pro)
    df['vwap'] = df['typ_vol'].cumsum() / df['volume'].cumsum()
    
    # Desviación Estándar Móvil (100 períodos como en el backtest)
    df['std_dev'] = df['close'].rolling(100).std()
    
    # Filtro de tendencia EMA 200
    df['ema_200'] = df['close'].ewm(span=200).mean()
    
    df['upper'] = df['vwap'] + (df['std_dev'] * mult)
    df['lower'] = df['vwap'] - (df['std_dev'] * mult)
    
    return df

def get_vwap_signals(df):
    """
    Retorna la señal actual basada en el cierre de la última vela completa.
    """
    if len(df) < 2: return None, None, None
    
    last = df.iloc[-1]
    prev = df.iloc[-2]
    
    # Lógica de Reversión + Filtro EMA
    # Short: Cruzó arriba y cerró adentro + Precio < EMA 200
    if prev['close'] > prev['upper'] and last['close'] < last['upper'] and last['close'] < last['ema_200']:
        return "SHORT", last['close'], last['upper']
        
    # Long: Cruzó abajo y cerró adentro + Precio > EMA 200
    if prev['close'] < prev['lower'] and last['close'] > last['lower'] and last['close'] > last['ema_200']:
        return "LONG", last['close'], last['lower']
        
    return None, None, None